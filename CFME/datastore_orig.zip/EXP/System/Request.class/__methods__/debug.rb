#provider = $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager).first
#$evm.log('info', "VISH_DEBUG #{provider.inspect}")
#provider.flavors.each do |flavor|
 #image.id.each do |id|
#  $evm.log('info', "VISH_DEBUG #{flavor.inspect}")
#  if image.id.to_i == 1
#    $evm.log('info', "VISH_DEBUG-if #{image.inspect}")
#    $evm.log('info', "VISH_DEBUG-if-hardware #{image.hardware.inspect}")
#    $evm.log('info', "VISH_DEBUG-if-operating_system #{image.operating_system['product_name']}")
#  end
#end
#groupname="Developers"
#group=$evm.vmdb('miq_group').find_by_description(groupname)
#user0='dev-vp'
#$evm.log('info', "VISH_DEBUG group desc #{group.description}")
#group.users.each do |user|
#  uid = user.userid.split('@')[0]
#  $evm.log('info', "VISH_DEBUG  user  name=  #{uid}")
#  if uid == user0
#  if user.tagged_with?('exp', 'vp')
#    $evm.log('info', "VISH_DEBUG list user =  #{user.id}")
#    $evm.log('info', "VISH_DEBUG user inspect =  #{user.inspect_all}")
#    $evm.log('info', "VISH_DEBUG user tagged_with =  #{user.tagged_with?('exp', 'vp')}") 
#    $evm.log('info', "VISH_DEBUG user tags =  #{user.tags}")
#  end
#end

#ci_owner = 'engineering'
#groups = $evm.vmdb(:miq_group).first

#.find(:all)
#groups.each do |group|
#  if group.tagged_with?("department", ci_owner)
#    $evm.log("info", "Group #{group.description} is tagged with department/#{ci_owner}")
#  end
#end

provider = $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager).first
$evm.log('info', "VISH_DEBUG-provider #{provider.inspect}")
provider.resource_groups.each do |group|
  $evm.log('info', "VISH_DEBUG-group #{group.name}")
end

