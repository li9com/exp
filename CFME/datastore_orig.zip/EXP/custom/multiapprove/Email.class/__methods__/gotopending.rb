level= $evm.root['miq_request'].options[:dialog]['dialog_applevel']
$evm.log("info", "VISH_DEBUG level = #{level}")
if level and level.to_i == 1
    $evm.log("info", "MULTI-LEVEL Pending")
	$evm.root["miq_request"].pending
else
    $evm.log("info", "AUTO-APPROVING")
    $evm.root["miq_request"].approve("admin", "Auto-Approved")
end
