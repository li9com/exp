require 'pg'
$evm.root['miq_request'].reload
#exit MIQ_OK
id=$evm.root['miq_request'].id
userid=$evm.root['miq_request'].get_option(:requesterid)
if userid.to_s.length > 0
	username=$evm.root['miq_request'].get_option(:requestername)
	useremail=$evm.root['miq_request'].get_option(:requesteremail)
	superstr = "update miq_requests set userid='#{username}',requester_id='#{userid}' where id='#{id}';"
	$evm.log('info', "VISH_DEBUG execute sql = #{superstr}")
	conn = PG.connect(:hostaddr=>'127.0.0.1', :port=>5432, :user=>"#{$evm.object['pguser']}", :password=>"#{$evm.object.decrypt('pgpassword')}", :dbname => 'vmdb_production')
	puts conn.exec(superstr)
	$evm.log('info', "VISH_DEBUG RETURN TASK TO username=#{username}")
	$evm.log('info', "VISH_DEBUG RETURN TASK TO userid=#{userid}")
	$evm.log('info', "VISH_DEBUG RETURN TASK TO useremail=#{useremail}")
end

appliance = $evm.root['miq_server'].ipaddress
#Croc specify
#appliance = "ccp.hosting.croc.ru:8000"
miq_request=$evm.root['miq_request']

$evm.log('info', "Next Approve email logic starting")
# Get appliance IP
@dialog_options_hash = miq_request.options[:dialog]
# Get requester email else set to nil
requester_email = $evm.root['miq_request'].get_option(:requesteremail)

# If to is still nil use to_email_address from model
to = nil
#to ||= $evm.object['to_email_address']
to ||= miq_request.get_option(:requesteremail)
to ||= miq_request.requester.email
# Get from_email_address from model unless specified below
from = nil
from ||= $evm.object['from_email_address']

# Get signature from model unless specified below
signature = nil
signature ||= $evm.object['signature']

# Build subject
subject = "Request ID #{miq_request.id} - Your Service provision request has denied"

body = "Hello, "
body += "<br>Your Service with email(#{requester_email}) provision request was denied by approver."
body += "<br><br>Approvers notes: #{miq_request.reason}"

body += "<br><br>Request details: "
if @dialog_options_hash.key?('dialog_service_name')
  body += "<br><br>&nbsp;&nbsp;Service description: #{@dialog_options_hash['dialog_service_name']}"
else
  body += "<br><br>&nbsp;&nbsp;Service description: #{miq_request.description}"
end
  body += "<br><br>&nbsp;&nbsp;Service options selected: "

def dialog_options(options_hash)
  options = []
  options_hash.each do |option, value|
    next if /(^tag|^dialog_tag|^.*guid.*$).*/ =~ option
    options << {option.to_s.sub(/^dialog_option_\d+_/, '').sub(/^dialog_/, '') => value}
  end
  options
end

#dialog_options(@dialog_options_hash).each do |option| 
#  key, value = option.flatten
#  body += "<br>&nbsp;&nbsp;&nbsp;&nbsp;#{key}: #{value}"
#end


body += "<br><br> Sorry for you,"
body += "<br> #{signature}"

# Send email
$evm.log("info", "Sending email to <#{to}> from <#{from}> subject: <#{subject}>")
$evm.execute(:send_email, to, from, subject, body)

