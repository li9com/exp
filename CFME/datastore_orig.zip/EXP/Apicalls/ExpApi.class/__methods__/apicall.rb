exit MIQ_OK
#
# Description: <Method description here>
#
require 'rubygems'
require 'rest-client'
require 'pg'
vm_name = $evm.root['dialog_vm_name'].to_s
#getid = "select id from vms where name='#{vm_name}';"
#conn = PGconn.open(:hostaddr=>'127.0.0.1', :port=>5432, :user=>'root', :password=>'P@ssw0rd', :dbname => 'vmdb_production')
#puts vmid = conn.exec(getid)
#id = vmid.getvalue(0,0)

#options = {
#  :method       => :get,
#  :url          => "https://admin:compaq@172.24.17.73/api/vms/#{id}?expand=resources&attributes=name,ipaddresses/",
#  :headers      => {:content_type=>'application/json'},
#  :verify_ssl  => false,
#}
#resource = RestClient::Request.new(options).execute
#response = JSON.parse(resource)
#ipadr = response["ipaddresses"][0]
#$evm.log(:info, '------------------------------')
#$evm.log(:info, ipadr)
#$evm.log(:info, '------------------------------')

ENV['http_proxy'] = "#{$evm.object['http_proxy']}"
ENV['https_proxy'] = "#{$evm.object['https_proxy']}"
ipaddr=''
options = {
  :method       => :post,
  :url          => "https://#{$evm.object['username']}:#{$evm.object.decrypt('password')}@#{$evm.object['username']}",
  :headers      => {:content_type=>'application/json'},
#  :verify_ssl  => false,
  :payload      => {
        :fields => {
        :project => {:key => 'Project1'},
        :parent => {:key => 'Parent1'},
        :summary => "processed #{$evm.root['service'].name} with IP #{ipaddr}",
        :description => "processed #{$evm.root['service'].name} with #{$evm.root['dialog_vm_name']}  IP: #{ipaddr}",
        :issuetype => {:id => '5'},
        },
        }.to_json,
}
RestClient::Request.new(options).execute
