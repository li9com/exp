provider = $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager).first
if provider
  provider.cloud_networks.each do |network|
#    next unless flavor.enabled
#    dialog_hash[flavor.id] = "#{flavor.name} on #{provider.name}"
    $evm.log('info', "VISH_DEBUG #{network.name} on #{provider.name} with id #{network.id}")
    network.cloud_subnets.each do |subnet|
        $evm.log('info', "VISH_DEBUG #{subnet.name} on #{network.name} with id #{subnet.id}")
    end
  end
#else
#  $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager_Flavor).all.each do |flavor|
#    next unless flavor.ext_management_system || flavor.enabled
#    dialog_hash[flavor.id] = "#{flavor.name} on #{flavor.ext_management_system.name}"
#    $evm.log('info', "VISH_DEBUG #{flavor.name} on #{flavor.ext_management_system.name}")
#  end
end
