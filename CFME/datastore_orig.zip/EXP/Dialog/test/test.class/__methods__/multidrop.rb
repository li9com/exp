dialog_field = $evm.object
dialog_field["values"] = [[1, "strace"], [2, "tcpdump"], [3, "telnet"], [4, "vim"]]
dialog_field["default_value"] = ['1','2']
conn=$evm.object['param_ansible_connection']
conn["value"] = ['ssh']
