dialog_field = $evm.object

def win(dialog_field)
  dialog_field["value"] = '5986'
end

def linux(dialog_field)
  dialog_field["value"] = '22'
end

####Section to use during dialog
dialog_image = $evm.root['dialog_src_vm_id']
$evm.log('info', "VISH_DEBUG-dialog_image #{dialog_image}")
if dialog_image
	provider = $evm.vmdb(:ManageIQ_Providers_InfraManager).first
	provider.miq_templates.each do |image|
 	 $evm.log('info', "VISH_DEBUG #{image.id}")
 	 if image.id.to_i == dialog_image.to_i
 	   $evm.log('info', "VISH_DEBUG-if #{image.inspect}")
	    $evm.log('info', "VISH_DEBUG-if-hardware #{image.hardware.inspect}")
	    $evm.log('info', "VISH_DEBUG-if-operating_system #{image.operating_system['product_name']}")
        if image.hardware['guest_os'] == "windows9server64"
          win(dialog_field)
        else
          linux(dialog_field)
        end
	  end
	end
end
