usergrp=$evm.root['user'].ldap_group
appuser=$evm.object
$evm.log('info',"VISH_DEBUG usergrp = #{usergrp}")
if usergrp=="Developers"
  appuser['value']='dev-owner'
elsif usergrp=="expusers"
  appuser['value']='admin'
else
  appuser['value']='admin'
end
  
