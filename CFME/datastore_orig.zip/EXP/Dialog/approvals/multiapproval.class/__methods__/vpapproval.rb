usergrp=$evm.root['user'].ldap_group
appuser=$evm.object
totalcost=$evm.root['dialog_threeyear-cost'].to_i
if totalcost > 5000
    $evm.object['visible'] = true
	if usergrp=="Developers"
	  appuser['value']='dev-vp'
	elsif usergrp=="expusers"
	  appuser['value']='admin'
	else
 	 appuser['value']='admin'
	end
else
  $evm.object['visible'] = false
end
