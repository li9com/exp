dialog_field = $evm.object

def win(dialog_field)
  dialog_field["value"] = 'winrm'
end

def linux(dialog_field)
  dialog_field["value"] = 'ssh'
end

#####Section to use during button
if $evm.root['vm']
	if $evm.root['vm'].hardware=='windows9server64' || $evm.root['vm'].platform == 'windows'
	  win(dialog_field)
	else
	  linux(dialog_field)
	end
end
