instflavor=$evm.root['dialog_instance_type']
dialog=$evm.object
if instflavor
	provider = $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager).first
	provider.flavors.each do |flavor|
 	 $evm.log('info', "VISH_DEBUG-flavor #{flavor.id}")
 	 if flavor.id.to_i == instflavor.to_i
       $evm.log('info', "VISH_DEBUG-flavorinspect #{flavor.inspect}")
 	   $evm.log('info', "VISH_DEBUG-flavorname #{flavor.name}")
	   case flavor.name
         when "Basic_A0"
		   cost="13.39"
		 when "Basic_A1"
		   cost="18.60"
		 when "Basic_A2"
		   cost="63.24"
		 when "Basic_A3"
		   cost="139.87"
		 when "Basic_A4"
		   cost="279.74"
         when "Standard_A0"
		   cost="14.88"
		 when "Standard_A1"
		   cost="44.64"
		 when "Standard_A2"
		   cost="89.28"
		 when "Standard_A2_v2"
		   cost="67.70"
		 when "Standard_A3"
		   cost="178.56"
		 else
			cost="1000"
       end
       dialog['value']=cost
       break
	  end
	end
end
