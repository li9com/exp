$evm.enable_rbac
def get_current_group_rbac_array(user, rbac_array=[])
    unless user.current_group.filters.blank?
      user.current_group.filters['managed'].flatten.each do |filter|
        next unless /(?<category>\w*)\/(?<tag>\w*)$/i =~ filter
        rbac_array << {category=>tag}
      end
    end
    $evm.log(:info, "rbac filters: #{rbac_array}")
    rbac_array
end
  
def service_visible?(rbac_array, service)
    rbac_array.each do |rbac_hash|
      rbac_hash.each {|category, tag| return false unless service.tagged_with?(category, tag)}
    end
    $evm.log(:info, "Object: #{service.name} is visible to this user")
    true
end
user = $evm.root['user']
rbac_array = get_current_group_rbac_array(user)
#instflavor=$evm.root['dialog_instance_type']
dialog=$evm.object
#ht = Hash.new {|h,k| h[k]=[]}
vish_hash = {}
vish_hash['!'] = '-- select from list --'
if dialog
	provider = $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager).first
    
    flavorlist=$evm.vmdb(:Flavor).first
    $evm.log('info', "VISH_DEBUG-flavorbase #{flavorlist.inspect}")
#    exit MIQ_OK
	provider.flavors.each do |flavor|
#    flavorlist.each do |flavor|
# 	  $evm.log('info', "VISH_DEBUG-flavorinspect #{flavor.inspect}")
#      $evm.instantiate('/Discovery/ObjectWalker/configuration')
#      break
#      if service_visible?(rbac_array, flavor)
      vish_hash[flavor.id] = "cpu: #{flavor.cpus} core, ram: #{flavor.memory/1048576} GiB, name: #{flavor.name}"
#      if flavor.id.to_i > 1
#        break
#      end
      $evm.log('info', "VISH_DEBUG-flavorrbac(name: #{flavor.name}")
#     dialog["values"] = {1 => "one", 2 => "two", 10 => "ten", 50 => "fifty"}
#     dialog["default_value"] = 2
# 	 if flavor.id.to_i == instflavor.to_i
#       $evm.log('info', "VISH_DEBUG-flavorinspect #{flavor.inspect}")
# 	   $evm.log('info', "VISH_DEBUG-flavorcpus #{flavor.cpus}")
#       dialog['value']=flavor.cpus
#       break
#	  end
	end
    list_values = {
     'sort_by'    => :value,
     'data_type'  => :string,
     'required'   => true,
     'values'     => vish_hash
 	 }
 	 list_values.each { |key, value| $evm.object[key] = value }
end
