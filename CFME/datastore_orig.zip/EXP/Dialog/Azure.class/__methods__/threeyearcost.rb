mcost=$evm.root['dialog_month-cost']
threeyearcost=$evm.object
threeyearcost['value']=mcost.to_i*12*3
