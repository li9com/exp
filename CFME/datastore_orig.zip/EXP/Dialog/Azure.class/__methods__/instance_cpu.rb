instflavor=$evm.root['dialog_instance_type']
dialog=$evm.object
if instflavor
	provider = $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager).first
	provider.flavors.each do |flavor|
 	 $evm.log('info', "VISH_DEBUG-flavor #{flavor.id}")
 	 if flavor.id.to_i == instflavor.to_i
       $evm.log('info', "VISH_DEBUG-flavorinspect #{flavor.inspect}")
 	   $evm.log('info', "VISH_DEBUG-flavorcpus #{flavor.cpus}")
       dialog['value']=flavor.cpus
       break
	  end
	end
end
