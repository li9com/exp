mcost=$evm.root['dialog_month-cost']
oneyearcost=$evm.object
oneyearcost['value']=mcost.to_i*12
