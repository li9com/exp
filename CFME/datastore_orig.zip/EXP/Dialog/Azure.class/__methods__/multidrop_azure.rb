dialog_field = $evm.object
#vish_hash = {}
#vish_hash['!'] = '-- select from list --'
def win(dialog_field)
#  dialog_field["values"] = [["Web-Server", "Web-Server"], ["FS-FileServer","FS-FileServer"]]
   dialog_field["values"] = [["7zip", "7zip"], ["git", "git"], ["firefox", "firefox"] ]
#   vish_hash["7zip"] = "7zip"
#   vish_hash["git"] = "git"
#   vish_hash["firefox"] = "firefox"
#   dialog_field["values"] = vish_hash
end

def linux(dialog_field)
   dialog_field["values"] = [["strace", "strace"], ["tcpdump", "tcpdump"], ["telnet", "telnet"], ["vim", "vim"]]
#   vish_hash["strace"] = "strace"
#   vish_hash["tcpdump"] = "tcpdump"
#   vish_hash["telnet"] = "telnet"
#   vish_hash["vim"] = "vim"
#   dialog_field["values"] = vish_hash
end

####Section to use during dialog
dialog_image = $evm.root['dialog_src_vm_id']
#$evm.log('info', "VISH_DEBUG-dialog_image #{dialog_image}")
if dialog_image
	provider = $evm.vmdb(:ManageIQ_Providers_Azure_CloudManager).first
	provider.miq_templates.each do |image|
# 	 $evm.log('info', "VISH_DEBUG #{image.id}")
 	 if image.id.to_i == dialog_image.to_i
# 	   $evm.log('info', "VISH_DEBUG-ifimageinspect #{image.inspect}")
       image.virtual_column_names.each do |image0|
#         $evm.log('info', "VISH_DEBUG-image0inspect #{image0} = #{image.send(image0)}")
       end
#	    $evm.log('info', "VISH_DEBUG-if-hardware #{image.hardware.inspect}")
#	    $evm.log('info', "VISH_DEBUG-if-operating_system #{image.operating_system['product_name']}")
        if image.operating_system['product_name'] == "Windows"
          win(dialog_field)
        else
          linux(dialog_field)
        end
	  end
	end
end
